﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication2
{
    class Program
    {
        static StreamWriter data = new StreamWriter("data.txt");
        static void Main(string[] args)
        {
            data.AutoFlush = true;
            StreamReader file = new StreamReader("C:\\Users\\aneeba majeed\\Desktop\\updatedata.csv");
            file.ReadLine();
            int i = 0;
            while(!file.EndOfStream)
            {
                string line = file.ReadLine();
                string[] columns = line.Split(',');
                data.Write(i + "," + columns[1]);
                checkType(columns[2]);
                i++;
                data.WriteLine();
            }
        }
        static void checkType(string t)
        {
            string[] types = t.Split('|');
            if (types.Contains<string>("Action")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Adventure")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Children")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Crime")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Thriller")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Romance")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Comedy")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Horror")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Animation")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Fantasy")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Drama")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Mystery")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Sci-Fi")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("War")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Musical")) data.Write("," + "1");
            else data.Write("," + "0");
            if (types.Contains<string>("Documentary")) data.Write("," + "1");
            else data.Write("," + "0");


        }
    }
}
